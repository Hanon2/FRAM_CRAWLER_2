﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Elcometer.Demo.Xamarin.Forms.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class BatchInfoPage : ContentPage
    {
        public BatchInfoPage()
        {
            InitializeComponent();
        }
    }
}