﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Elcometer.Demo.Xamarin.Forms.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class GaugePage : ContentPage
    {
        public GaugePage()
        {
            InitializeComponent();
        }
    }
}