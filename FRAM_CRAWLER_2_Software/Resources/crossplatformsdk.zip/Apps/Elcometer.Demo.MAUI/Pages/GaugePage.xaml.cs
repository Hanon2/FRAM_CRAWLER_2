﻿
namespace Elcometer.Demo.Xamarin.Forms.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class GaugePage : ContentPage
    {
        public GaugePage()
        {
            InitializeComponent();
        }
    }
}