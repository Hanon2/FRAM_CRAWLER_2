﻿namespace Elcometer.Demo.Xamarin.Forms.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class BatchInfoPage : ContentPage
    {
        public BatchInfoPage()
        {
            InitializeComponent();
        }
    }
}