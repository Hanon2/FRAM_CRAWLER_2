﻿
namespace Elcometer.Demo.Xamarin.Forms.Pages
{
    public partial class BatchesPage : ContentPage
    {
        public BatchesPage()
        {
            InitializeComponent();
        }
    }
}